<!DOCTYPE html>
<html>
<head>
    <title><?php echo e($title); ?></title>
    <style>
        body { 
            font-family: 'DejaVu Sans', sans-serif; 
            font-size: 8px; /* Reduced font size */
        }
        table { 
            width: 100%; 
            border-collapse: collapse; 
            margin-bottom: 10px; /* Slightly reduced margin */
        }
        th, td { 
            border: 1px solid #ddd; 
            padding: 4px; /* Reduced padding */
            text-align: left; 
            vertical-align: top; 
            word-wrap: break-word; /* Allow long words to break */
        }
        th { 
            background-color: #f2f2f2; 
            white-space: nowrap; /* Prevent headings from wrapping if they are short, or explicitly control */
        }
        .header { text-align: center; margin-bottom: 20px; }
        .header h1 { margin: 0; font-size: 16px; }
        .header p { margin: 0; font-size: 10px; }
        .user-info { margin-bottom: 15px; border: 1px solid #eee; padding: 8px; border-radius: 5px;}
        .user-info p { margin: 2px 0; }
        .section-title { font-size: 12px; font-weight: bold; margin-top: 15px; margin-bottom: 8px; }

        /* Landscape orientation for dompdf */
        @page { 
            size: A4 landscape; /* Set page to A4 landscape */
        }
    </style>
</head>
<body>
    <div class="header">
        <h1><?php echo e($title); ?></h1>
        <p>Tanggal Laporan: <?php echo e($date); ?></p>
        <p>Rumah Sakit: <?php echo e($userInfo->hospital->name ?? 'N/A'); ?></p>
        <p>Ruangan: <?php echo e($userInfo->department->name ?? 'N/A'); ?></p>
        <p>Kepala Ruangan: <?php echo e($userInfo->name ?? 'N/A'); ?></p>
    </div>

    <div class="user-info">
        <p><strong>Kepala Ruangan:</strong> <?php echo e($userInfo->name ?? 'N/A'); ?></p>
        <p><strong>Jabatan:</strong> Kepala Ruangan <?php echo e($userInfo->department->name ?? 'N/A'); ?></p>
        <p><strong>Rumah Sakit:</strong> <?php echo e($userInfo->hospital->name ?? 'N/A'); ?></p>
    </div>

    <h2>Inventaris Logistik Ruangan</h2>
    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Barang</th>
                <th>Kategori</th>
                <th>Merk</th>
                <th>Stok</th>
                <th>Satuan</th>
                <th>Status</th>
                <th>Kode Barang</th>
                <th>Jadwal Maint.</th> 
                <th>Tgl Kalibrasi</th> 
                <th>Kadaluarsa Kalibrasi</th> 
                <th>Catatan</th>
                <th>Terakhir Diperbarui</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $logistics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td><?php echo e($item->item_name); ?></td>
                    <td><?php echo e($item->category); ?></td>
                    <td><?php echo e($item->brand ?? '-'); ?></td>
                    <td><?php echo e($item->stock); ?></td>
                    <td><?php echo e($item->unit_of_measure ?? '-'); ?></td>
                    <td><?php echo e($item->status); ?></td>
                    <td><?php echo e($item->item_code ?? '-'); ?></td>
                    <td><?php echo e($item->maintenance_schedule ?? '-'); ?></td>
                    <td><?php echo e($item->calibration_date ? \Carbon\Carbon::parse($item->calibration_date)->format('d-m-Y') : '-'); ?></td>
                    <td><?php echo e($item->calibration_expiry_date ? \Carbon\Carbon::parse($item->calibration_expiry_date)->format('d-m-Y') : '-'); ?></td>
                    <td><?php echo e($item->notes ?? '-'); ?></td>
                    <td><?php echo e($item->updated_at ? \Carbon\Carbon::parse($item->updated_at)->format('d-m-Y H:i') : '-'); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="13" style="text-align: center;">Tidak ada data logistik.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html><?php /**PATH C:\Users\Lenovo\easy-manage\resources\views/reports/logistics_pdf.blade.php ENDPATH**/ ?>